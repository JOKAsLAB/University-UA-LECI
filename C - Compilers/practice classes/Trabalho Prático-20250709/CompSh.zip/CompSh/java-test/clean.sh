#!/bin/bash

java-clean

