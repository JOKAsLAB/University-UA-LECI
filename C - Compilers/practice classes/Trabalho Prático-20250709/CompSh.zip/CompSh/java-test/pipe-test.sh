#!/bin/bash

ls | java Pipe sort -r

ls | java Pipe sort

