#!/bin/bash

java RunExternalProgram ls

java RunExternalProgram ls ksjdhfkjdhg
