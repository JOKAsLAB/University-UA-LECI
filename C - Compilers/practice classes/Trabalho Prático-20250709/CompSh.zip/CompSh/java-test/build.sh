#!/bin/bash

javac *.java

