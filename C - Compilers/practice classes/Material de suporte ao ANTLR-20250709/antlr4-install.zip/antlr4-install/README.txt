Linux (debian based, such as ubuntu) compiler/interpreter development installation (includes antlr4, stringtemplate, java jdk, antlr4 scripts, offline libraries documentation, vim antlr4 syntax highlight).

To install run:

./install.sh

You may install over an existing installation.
The script will ask to confirm removal of files of a previous installation.
You may also skip some parts of the installation.

./remove.sh

Remove a previous installation.
