public class RealType extends Type {
   public RealType() {
      super("real");
   }

   public boolean isNumeric() {
      return true;
   }
}

