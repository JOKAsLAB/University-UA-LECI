
If needed, compile with

g++ -Wall -Wextra -std=c++17 main.cpp Fraction.cpp