
Compile with

g++ set_example.cpp Fraction.cpp -Wall -Wextra -std=c++17