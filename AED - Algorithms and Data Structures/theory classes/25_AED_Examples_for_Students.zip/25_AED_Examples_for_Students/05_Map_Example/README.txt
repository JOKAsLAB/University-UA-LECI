
Compile with

g++ map_example.cpp Fraction.cpp -Wall -Wextra -std=c++17