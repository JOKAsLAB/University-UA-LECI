
Ficheiros TXT de Sedgewick & Wayne


G - Graph - Grafo não orientado

DG - Digraph - Grafo orientado

DAG - Directed Acyclic Graph - Grafo orientado acíclico

EWD - Edge-Weighted Digraph - Grafo orientado com custos/pesos associados às arestas


ATENÇÃO:

Há lacetes nalguns dos ficheiros (vi = vj).
Identificar na função de leitura e não acrescentar essas arestas.

FORMATO:

0 / 1 É grafo orientado ?
0 / 1 Há pesos associados às arestas ?
Número de vértices
Número de arestas
vértice inicial vértice final (peso, se existir)
....
....