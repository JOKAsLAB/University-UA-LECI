import java.util.List;

public interface IGradeCalculator {

    double calculate(List<Double> grades);
}
