# coding: utf-8

# Execute the program and see what happens.
# Then modify the program so that X is replaced by the course input.
# Hint: see what we did with the name and surname.

name = input("Primeiro nome? ")
surname = input("Apelido? ")
course = input("Curso? ")

print("Olá {} {}!\nBem vindo ao curso de X!".format(name, surname))

