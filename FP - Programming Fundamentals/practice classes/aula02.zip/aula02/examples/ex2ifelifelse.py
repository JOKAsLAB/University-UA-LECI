# Example: if-elif-else statement

x = float(input("X? "))
y = float(input("Y? "))

if x > y:
    print('x is greater than y')
elif x < y:
    print('x is less than y')
else:
    print('x and y are equal')

print("END")
